/*********************************************************** 
 * Programming Assignment 1
 * Students program
 * Programmer: Mark Eatough
 * Course: CS1410 
 * Created January 26, 2012
 * Modified February 2, 2012
 * Modified by Mark Eatough
 ***********************************************************/
	
   public class StudentApp
   {
      public static void main(String[] args)
      {	
        	// call class
         StudentList myStudentList = new StudentList();
			
			//call menu
			myStudentList.studentMenu();
      }
  
   }//end student list class