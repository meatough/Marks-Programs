'''
*********************************************************** 
 * Discrete Structures
 * Trip Through Germany Program
 * Programmer: Mark Eatough
 * Course: CSIS 2430 
 * Created Novermber 3, 2013

 ***********************************************************
'''

#class to create and manage dollars object
class Dollars: 
   def __init__(self, dollars):
      self.dollars = dollars
  #toString method equivalent
   def __str__(self):
      return("${0:.2f}".format(self.dollars))    
#class to create and manage euros object
class Euros:
   def __init__(self, euros):
      self.euros = euros
   #toString method equivalent
   def __str__(self):
      return("{0:.2f} Euros".format(self.euros))
#class to create and manage time object
class Time:
   def __init__(self, hours, miniutes):
      self.hours = hours
      self.miniutes = miniutes
      while(self.miniutes > 60):
         self.hours += 1
         self.miniutes -= 60
   #toString method equivalent
   def __str__(self):
      return("{0} Hours {1} Miniutes".format(self.hours,self.miniutes))       
   #method to add two times together
   def addTime(self, otherTime):
      myHours = self.hours+otherTime.hours
      myMiniutes = self.miniutes+otherTime.miniutes
      while(myMiniutes > 60):
         myMiniutes -= 60
         myHours += 1
      myTime = Time(myHours, myMiniutes)
      return myTime


#CONVERSTIONS

#conversion rate found on xrates.com, rounded to the nearest cent
def convertToEuros(dollars):
   euros = dollars * 0.74
   return Euros(euros)
#conversion rate found on xrates.com, rounded to the nearest cent
def convertToDollars(euros):
   dollars = euros * 1.35
   return Dollars(dollars)
#Converstion from miles to kilometers
def convertToKilometers(miles):
   miles = kilometers * 0.62
   return miles
#Conversion from kilometers to miles
def convertToMiles(kilometers):
   kilometers = miles * 1.6
   return kilometers