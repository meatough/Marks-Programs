 /*********************************************************** 
 * Name: Mark Eatough
 * Course: CS1400 
 * Assignment: A9
 ***********************************************************/ 
import java.util.Scanner;
 
public class StudentTest
{
	public static void main(String[] args)
	{
		Scanner input;
		input = new Scanner(System.in);
		
		int i = 0;
		do
		{
		System.out.print("\nFirst Name: ");
		String firstName  = input.nextLine();
		
		System.out.print("\nLast Name: ");
		String lastName  = input.nextLine();

		
		Student myStudent = new Student(firstName, lastName);
		System.out.printf("%s", myStudent);
		
		myStudent.doAssignment();
		
		i++;
		}while(i<5);
	}

}
