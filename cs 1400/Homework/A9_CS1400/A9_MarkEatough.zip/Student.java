 /*********************************************************** 
 * Name: Mark Eatough
 * Course: CS1400 
 * Assignment: A9
 ***********************************************************/ 
import java.util.Random;

public class Student
{
	//private fields
	private String firstName;
	{
	}
	
	private String lastName;
	{
	}
	
	private String studentNumber;
	{
	}
	
	private static int sNumber = 123455;
	{
	}
	
	
	//constructors 
	public Student (String fName, String lName)
	{
		firstName = fName;
		lastName = lName;
	
		++sNumber;
		studentNumber = "SS00" + sNumber;		
	}
	
	//methods
	public static void doAssignment()
	{
		Random rand = new Random();
		final int ARRAY_LENGTH = 13;
		int[] dice = new int[ARRAY_LENGTH];
		
		System.out.print("\n	Sum		Frequency	Percentage");
								
		for (int i = 0; i< 100000; i++)
		{
			int diceRolls = 1 + rand.nextInt(6) + 1 + rand.nextInt(6);
			++dice[diceRolls];
		}
		
		for (int i = 2; i < ARRAY_LENGTH; i++)
		{
			System.out.println();
			System.out.printf("	%d		%d		%d%%",i,dice[i],dice[i]/1000);
		}		
	}

	@Override
	public String toString()
	{
		return String.format("%s: %s %s", studentNumber, firstName, lastName);
	}
}