 /*********************************************************** 
 * Name: Mark Eatough
 * Course: CS1400 
 * Assignment: A1 
 ***********************************************************/ 

import java.util.Scanner;

public class A1
{
	public static void main(String[] args)
	{
	Scanner input = new Scanner(System.in);
	int number;
	
	System.out.print("Please enter a positive 5 digit integer:  ");
	number=input.nextInt();
	
	int firstdigit=number/10000;
	int seconddigit=number/1000 % 10;
	int thirddigit=number/100 % 10;
	int fourthdigit=number/10 % 10;
	int fifthdigit=number % 10;

	System.out.printf("%d %d %d %d %d", firstdigit, seconddigit, thirddigit, fourthdigit, fifthdigit);
	}
}